from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

__prog__ = 'AntShell'
__version__ = '0.4.12'
__author__  = 'Casstiel'
