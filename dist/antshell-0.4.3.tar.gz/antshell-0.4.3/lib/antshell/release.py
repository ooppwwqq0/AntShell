from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

__version__ = '0.4.3'
__author__  = 'Casstiel'
