
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from antshell.release import __prog__, __version__, __author__
from antshell import lang
from antshell import base
from antshell.AntShell import main
